<html>
<body>

<p>MENSAGEM ENVIADA POR CLIENTE DO SITE SMART VEICULOS</p>
<p>NOME: <?php echo e($user['nome']); ?></p>
<p>EMAIL: <?php echo e($user['email']); ?></p>
<p>TELEFONE: <?php echo e($user['telefone']); ?></p>
<p>ENDEREÇO: <?php echo e($user['endereco']); ?></p>
<p>MENSAGEM: <?php echo e($user['mensagem']); ?></p>

</body>
</html>
<?php /**PATH /var/www/html/smart/resources/views/email/template-veiculos.blade.php ENDPATH**/ ?>