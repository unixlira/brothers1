<html>
<body>

<p>MENSAGEM ENVIADA POR CLIENTE DO SITE SMART VEICULOS ANÁLISE DE CRÉDITO</p>
<p>NOME: <?php echo e($user['nome']); ?></p>
<p>DATA NASCIMENTO: <?php echo e($user['nascimento']); ?></p>
<p>RG: <?php echo e($user['rg']); ?></p>
<p>CPF: <?php echo e($user['cpf']); ?></p>
<p>NOME DA MÃE: <?php echo e($user['mae']); ?></p>
<p>ENDEREÇO: <?php echo e($user['endereco']); ?></p>
<p>CIDADE: <?php echo e($user['cidade']); ?></p>
<p>TELEFONE: <?php echo e($user['telefone']); ?></p>
<p>CELULAR1: <?php echo e($user['celular1']); ?></p>
<p>CELULAR2: <?php echo e($user['celular2']); ?></p>
<p>NOME DA EMPRESA: <?php echo e($user['empresa']); ?></p>
<p>CARGO: <?php echo e($user['cargo']); ?></p>
<p>RENDA: <?php echo e($user['renda']); ?></p>
<p>TEMPO DE EMPRESA: <?php echo e($user['tempoempresa']); ?></p>
<p>MENSAGEM: <?php echo e($user['mensagem']); ?></p>

</body>
</html>
<?php /**PATH /var/www/html/smart/resources/views/email/template-analise.blade.php ENDPATH**/ ?>