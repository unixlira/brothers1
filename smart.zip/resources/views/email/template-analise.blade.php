<html>
<body>

<p>MENSAGEM ENVIADA POR CLIENTE DO SITE SMART VEICULOS ANÁLISE DE CRÉDITO</p>
<p>NOME: {{$user['nome']}}</p>
<p>DATA NASCIMENTO: {{$user['nascimento']}}</p>
<p>RG: {{$user['rg']}}</p>
<p>CPF: {{$user['cpf']}}</p>
<p>NOME DA MÃE: {{$user['mae']}}</p>
<p>ENDEREÇO: {{$user['endereco']}}</p>
<p>CIDADE: {{$user['cidade']}}</p>
<p>TELEFONE: {{$user['telefone']}}</p>
<p>CELULAR1: {{$user['celular1']}}</p>
<p>CELULAR2: {{$user['celular2']}}</p>
<p>NOME DA EMPRESA: {{$user['empresa']}}</p>
<p>CARGO: {{$user['cargo']}}</p>
<p>RENDA: {{$user['renda']}}</p>
<p>TEMPO DE EMPRESA: {{$user['tempoempresa']}}</p>
<p>MENSAGEM: {{$user['mensagem']}}</p>

</body>
</html>
