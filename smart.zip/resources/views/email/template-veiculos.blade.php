<html>
<body>

<p>MENSAGEM ENVIADA POR CLIENTE DO SITE SMART VEICULOS</p>
<p>NOME: {{$user['nome']}}</p>
<p>EMAIL: {{$user['email']}}</p>
<p>TELEFONE: {{$user['telefone']}}</p>
<p>ENDEREÇO: {{$user['endereco']}}</p>
<p>MENSAGEM: {{$user['mensagem']}}</p>

</body>
</html>
